#!/usr/bin/env python3
"""
Превращает исходный пак (Blockbench-модели) в ресурсы мода.

  python3 tools/build_assets.py

Что делает:
  * режет pistol_java.json по группам (slide/frame/magazine/trigger/hammer) на отдельные
    модели, чтобы каждую деталь можно было анимировать независимо;
  * конвертирует анимации из pistol_animated.bbmodel в assets/pistolmod/animations/pistol.json;
  * копирует текстуры и модели патрона/гильзы/пули/вспышки, заменяя `modid:` на `pistolmod:`.

Если поменяешь модель/анимацию в Blockbench - положи новые файлы в tools/source_pack
и запусти скрипт заново.
"""
import json, shutil
from pathlib import Path

MODID = "pistolmod"
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "tools" / "source_pack"
ASSETS = ROOT / "src" / "main" / "resources" / "assets" / MODID
MODELS = ASSETS / "models" / "item"
TEX = ASSETS / "textures" / "item"
ANIM = ASSETS / "animations"
for d in (MODELS, TEX, ANIM):
    d.mkdir(parents=True, exist_ok=True)

def fix_tex(model):
    model["textures"] = {k: v.replace("modid:", MODID + ":") for k, v in model["textures"].items()}
    return model

# ---------- пистолет: разбиваем на детали ----------
pistol = json.loads((SRC / "pistol" / "pistol_java.json").read_text())
fix_tex(pistol)
for g in pistol["groups"]:
    part = {
        "credit": pistol.get("credit", ""),
        "texture_size": pistol["texture_size"],
        "textures": pistol["textures"],
        "elements": [pistol["elements"][i] for i in g["children"]],
    }
    (MODELS / f"pistol_{g['name']}.json").write_text(json.dumps(part, indent=1))
    print("part", g["name"], len(part["elements"]), "elements")

# основная модель предмета - builtin/entity, рисуется нашим BEWLR
item = {"parent": "builtin/entity", "gui_light": "side", "display": pistol["display"]}
(MODELS / "pistol.json").write_text(json.dumps(item, indent=1))

# ---------- патрон, гильза, пуля, вспышка ----------
for name in ("cartridge", "casing", "projectile", "muzzle_flash"):
    m = fix_tex(json.loads((SRC / "bullets" / f"{name}.json").read_text()))
    (MODELS / f"{name}.json").write_text(json.dumps(m, indent=1))
    shutil.copy(SRC / "bullets" / f"{name}.png", TEX / f"{name}.png")
shutil.copy(SRC / "pistol" / "pistol.png", TEX / "pistol.png")

# ---------- анимации ----------
bb = json.loads((SRC / "pistol" / "pistol_animated.bbmodel").read_text())
out = {}
for a in bb["animations"]:
    bones = {}
    for animator in a["animators"].values():
        tracks = {}
        for ch in ("position", "rotation", "scale"):
            kfs = []
            for kf in animator["keyframes"]:
                if kf["channel"] != ch:
                    continue
                dp = kf["data_points"][0]
                kfs.append({
                    "time": float(kf["time"]),
                    "value": [float(dp["x"]), float(dp["y"]), float(dp["z"])],
                    "smooth": kf.get("interpolation") == "catmullrom",
                })
            kfs.sort(key=lambda k: k["time"])
            if kfs:
                tracks[ch] = kfs
        bones[animator["name"]] = tracks
    out[a["name"]] = {"length": float(a["length"]), "loop": a.get("loop") == "loop", "bones": bones}
    print("anim", a["name"], a["length"], "s")
(ANIM / "pistol.json").write_text(json.dumps({"animations": out}, indent=1))
print("OK")
