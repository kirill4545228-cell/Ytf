pistol/pistol_animated.bbmodel  - Blockbench (Generic Model): hold, shoot, reload, inspect
pistol/pistol_java.bbmodel      - Blockbench (Java Block/Item) with display settings
pistol/pistol_java.json         - ready Java item model (texture: modid:item/pistol -> replace modid)
pistol/pistol.png               - texture
bullets/ cartridge, casing, projectile, muzzle_flash (.json/.bbmodel/.png)
