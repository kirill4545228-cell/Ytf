package com.pistolmod.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/** Вылетающая гильза. Физика считается на сервере, клиенты получают позицию как у любой сущности. */
public class CasingEntity extends Entity {
    public static final int LIFETIME = 50;

    public CasingEntity(EntityType<? extends CasingEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true); // гравитацию считаем сами
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        if (this.tickCount > LIFETIME) {
            this.discard();
            return;
        }

        Vec3 m = this.getDeltaMovement().add(0.0, -0.04, 0.0);
        this.move(MoverType.SELF, m);

        double nx = m.x * 0.98;
        double ny = m.y * 0.98;
        double nz = m.z * 0.98;
        if (this.horizontalCollision) {
            nx *= -0.3;
            nz *= -0.3;
        }
        if (this.verticalCollision && m.y < 0.0) {
            ny = Math.abs(m.y) > 0.12 ? -m.y * 0.45 : 0.0; // подпрыгивает
            nx *= 0.6;
            nz *= 0.6;
        }
        this.setDeltaMovement(nx, ny, nz);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
