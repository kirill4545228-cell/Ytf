package com.pistolmod.entity;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.network.NetworkHooks;

/** Пуля: быстрый снаряд, проверка попадания идёт по всему отрезку за тик, поэтому сквозь мобов не пролетает. */
public class BulletEntity extends Projectile {
    public static final float DAMAGE = 7.0F;
    private static final int MAX_AGE = 40;

    public BulletEntity(EntityType<? extends BulletEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    public void tick() {
        super.tick();

        HitResult hit = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
        if (hit.getType() != HitResult.Type.MISS && !ForgeEventFactory.onProjectileImpact(this, hit)) {
            this.onHit(hit);
        }
        if (this.isRemoved()) return;

        this.checkInsideBlocks();
        Vec3 motion = this.getDeltaMovement();
        double nx = this.getX() + motion.x;
        double ny = this.getY() + motion.y;
        double nz = this.getZ() + motion.z;
        this.updateRotation();

        float drag = 0.995F;
        if (this.isInWater()) {
            if (this.level().isClientSide) {
                this.level().addParticle(ParticleTypes.BUBBLE, nx, ny, nz, 0, 0, 0);
            }
            drag = 0.75F;
        }
        this.setDeltaMovement(motion.scale(drag).add(0.0, -0.012, 0.0));
        this.setPos(nx, ny, nz);

        if (this.tickCount > MAX_AGE && !this.level().isClientSide) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!(this.level() instanceof ServerLevel)) return;

        Entity target = result.getEntity();
        Entity owner = this.getOwner();
        float damage = DAMAGE;
        // попадание в голову
        if (target instanceof LivingEntity && result.getLocation().y > target.getEyeY() - 0.25) {
            damage *= 1.5F;
        }
        DamageSource source = this.damageSources().thrown(this, owner == null ? this : owner);
        if (target instanceof LivingEntity living) {
            living.invulnerableTime = 0; // чтобы очередь из выстрелов не «съедалась» неуязвимостью
        }
        target.hurt(source, damage);
        this.discard();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!(this.level() instanceof ServerLevel server)) return;

        BlockState state = server.getBlockState(result.getBlockPos());
        Vec3 p = result.getLocation();
        server.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), p.x, p.y, p.z, 8, 0.05, 0.05, 0.05, 0.1);
        server.sendParticles(ParticleTypes.SMOKE, p.x, p.y, p.z, 2, 0.02, 0.02, 0.02, 0.01);
        server.playSound(null, result.getBlockPos(), state.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.8F, 1.4F);
        this.discard();
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
