package com.pistolmod;

import com.pistolmod.network.ModNetwork;
import com.pistolmod.registry.ModCreativeTabs;
import com.pistolmod.registry.ModEntities;
import com.pistolmod.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import org.slf4j.Logger;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(PistolMod.MODID)
public class PistolMod {
    public static final String MODID = "pistolmod";
    public static final Logger LOGGER = LogUtils.getLogger();

    public PistolMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModCreativeTabs.TABS.register(bus);
        ModNetwork.register();
    }
}
