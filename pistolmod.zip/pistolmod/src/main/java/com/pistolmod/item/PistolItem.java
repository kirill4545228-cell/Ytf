package com.pistolmod.item;

import com.pistolmod.client.PistolClientHooks;
import com.pistolmod.client.PistolItemRenderer;
import com.pistolmod.entity.BulletEntity;
import com.pistolmod.entity.CasingEntity;
import com.pistolmod.registry.ModEntities;
import com.pistolmod.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

public class PistolItem extends Item {
    public static final int MAGAZINE_SIZE = 12;
    public static final int SHOOT_COOLDOWN = 6;
    /** Через сколько тиков после начала перезарядки патроны попадают в магазин (анимация длится 3.2 с). */
    public static final int RELOAD_TICKS = 58;
    public static final float BULLET_SPEED = 6.0F;
    public static final float BULLET_INACCURACY = 0.4F;

    private static final String TAG_AMMO = "Ammo";
    private static final String TAG_RELOAD_END = "ReloadEnd";

    public PistolItem(Properties properties) {
        super(properties);
    }

    // ------------------------------------------------------------------ состояние

    public static int getAmmo(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag == null ? 0 : tag.getInt(TAG_AMMO);
    }

    public static void setAmmo(ItemStack stack, int ammo) {
        stack.getOrCreateTag().putInt(TAG_AMMO, Mth.clamp(ammo, 0, MAGAZINE_SIZE));
    }

    public static boolean isReloading(ItemStack stack, Level level) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(TAG_RELOAD_END) && level.getGameTime() < tag.getLong(TAG_RELOAD_END);
    }

    /** Пистолет в основной руке, а если там нет - в левой. */
    public static ItemStack findHeld(Player player) {
        ItemStack main = player.getMainHandItem();
        if (main.getItem() instanceof PistolItem) return main;
        ItemStack off = player.getOffhandItem();
        if (off.getItem() instanceof PistolItem) return off;
        return ItemStack.EMPTY;
    }

    public static int countAmmo(Player player) {
        int count = 0;
        for (ItemStack s : player.getInventory().items) {
            if (s.is(ModItems.CARTRIDGE.get())) count += s.getCount();
        }
        for (ItemStack s : player.getInventory().offhand) {
            if (s.is(ModItems.CARTRIDGE.get())) count += s.getCount();
        }
        return count;
    }

    private static int takeAmmo(Player player, int max) {
        if (player.getAbilities().instabuild) return max;
        int left = max;
        left = takeFrom(player.getInventory().items, left);
        left = takeFrom(player.getInventory().offhand, left);
        return max - left;
    }

    private static int takeFrom(NonNullList<ItemStack> list, int left) {
        for (ItemStack s : list) {
            if (left <= 0) break;
            if (s.is(ModItems.CARTRIDGE.get())) {
                int n = Math.min(left, s.getCount());
                s.shrink(n);
                left -= n;
            }
        }
        return left;
    }

    public static boolean canReload(Player player, ItemStack stack, Level level) {
        return getAmmo(stack) < MAGAZINE_SIZE
                && !isReloading(stack, level)
                && (player.getAbilities().instabuild || countAmmo(player) > 0);
    }

    /** Вызывается на сервере по пакету от клиента (клавиша R). */
    public static void startReload(Player player, ItemStack stack) {
        Level level = player.level();
        if (level.isClientSide || !canReload(player, stack, level)) return;
        stack.getOrCreateTag().putLong(TAG_RELOAD_END, level.getGameTime() + RELOAD_TICKS);
    }

    // ------------------------------------------------------------------ выстрел

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (isReloading(stack, level) || player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        if (level.isClientSide) {
            Boolean animating = DistExecutor.unsafeCallWhenOn(Dist.CLIENT, () -> PistolClientHooks::isReloadAnimating);
            if (Boolean.TRUE.equals(animating)) return InteractionResultHolder.fail(stack);
        }

        if (getAmmo(stack) <= 0) {
            if (!level.isClientSide) {
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.8F, 1.6F);
            }
            player.getCooldowns().addCooldown(this, 10);
            return InteractionResultHolder.fail(stack);
        }

        player.getCooldowns().addCooldown(this, SHOOT_COOLDOWN);
        if (level.isClientSide) {
            // анимацию запускаем сразу, не дожидаясь сервера - так отклик мгновенный
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> PistolClientHooks::onShoot);
        } else {
            fire((ServerLevel) level, player, hand, stack);
        }
        // consume (а не success), чтобы ванильный взмах руки не дёргал пистолет
        return InteractionResultHolder.consume(stack);
    }

    private void fire(ServerLevel level, Player player, InteractionHand hand, ItemStack stack) {
        setAmmo(stack, getAmmo(stack) - 1);

        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 up = new Vec3(0, 1, 0);
        boolean rightArm = (hand == InteractionHand.MAIN_HAND) == (player.getMainArm() == HumanoidArm.RIGHT);
        double side = rightArm ? 1.0 : -1.0;
        Vec3 right = Vec3.directionFromRotation(0.0F, player.getYRot() + 90.0F);

        // пуля
        BulletEntity bullet = new BulletEntity(ModEntities.BULLET.get(), level);
        bullet.setOwner(player);
        bullet.setPos(eye.add(look.scale(0.4)));
        bullet.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, BULLET_SPEED, BULLET_INACCURACY);
        level.addFreshEntity(bullet);

        // гильза вылетает вправо-вверх
        RandomSource rnd = level.getRandom();
        CasingEntity casing = new CasingEntity(ModEntities.CASING.get(), level);
        casing.setPos(eye.add(look.scale(0.45)).add(right.scale(0.2 * side)).subtract(up.scale(0.15)));
        Vec3 vel = right.scale(side * (0.12 + rnd.nextFloat() * 0.06))
                .add(0.0, 0.10 + rnd.nextFloat() * 0.06, 0.0)
                .add(look.scale(-0.02 + rnd.nextFloat() * 0.04));
        Vec3 pm = player.getDeltaMovement();
        casing.setDeltaMovement(vel.add(pm.x, 0.0, pm.z));
        level.addFreshEntity(casing);

        // дымок у дула
        Vec3 muzzle = eye.add(look.scale(0.9)).add(right.scale(0.18 * side)).subtract(up.scale(0.12));
        level.sendParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 3, 0.02, 0.02, 0.02, 0.01);

        // звук (ванильные звуки; свои .ogg можно подключить через sounds.json)
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1.4F, 1.8F + rnd.nextFloat() * 0.2F);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.3F, 2.0F);
    }

    // ------------------------------------------------------------------ перезарядка

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !(entity instanceof Player player)) return;
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains(TAG_RELOAD_END)) return;

        boolean held = selected || player.getOffhandItem() == stack;
        if (!held) {
            tag.remove(TAG_RELOAD_END); // убрали пистолет из руки - перезарядка отменена
            return;
        }

        long end = tag.getLong(TAG_RELOAD_END);
        long now = level.getGameTime();
        long elapsed = now - (end - RELOAD_TICKS);
        double x = player.getX(), y = player.getY(), z = player.getZ();

        // звуки синхронизированы с анимацией (тики = секунды * 20)
        if (elapsed == 14) level.playSound(null, x, y, z, SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.PLAYERS, 0.5F, 1.7F);
        if (elapsed == 22) level.playSound(null, x, y, z, SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 0.7F, 1.4F);
        if (elapsed == 27) level.playSound(null, x, y, z, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.PLAYERS, 0.6F, 1.8F);
        if (elapsed == 49) level.playSound(null, x, y, z, SoundEvents.CROSSBOW_LOADING_END, SoundSource.PLAYERS, 0.8F, 1.6F);
        if (elapsed == 53) level.playSound(null, x, y, z, SoundEvents.LEVER_CLICK, SoundSource.PLAYERS, 0.6F, 1.9F);

        if (now >= end) {
            tag.remove(TAG_RELOAD_END);
            int taken = takeAmmo(player, MAGAZINE_SIZE - getAmmo(stack));
            setAmmo(stack, getAmmo(stack) + taken);
        }
    }

    // ------------------------------------------------------------------ прочее

    /** Без этого каждое изменение NBT (патроны) запускало бы ванильную анимацию смены предмета. */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public boolean shouldCauseBlockBreakReset(ItemStack oldStack, ItemStack newStack) {
        return oldStack.getItem() != newStack.getItem();
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.pistolmod.ammo", getAmmo(stack), MAGAZINE_SIZE)
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.pistolmod.controls").withStyle(ChatFormatting.DARK_GRAY));
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private PistolItemRenderer renderer;

            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) renderer = new PistolItemRenderer();
                return renderer;
            }
        });
    }
}
