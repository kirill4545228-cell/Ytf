package com.pistolmod.registry;

import com.pistolmod.PistolMod;
import com.pistolmod.item.PistolItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PistolMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + PistolMod.MODID))
                    .icon(() -> loadedPistol())
                    .displayItems((params, output) -> {
                        output.accept(loadedPistol());
                        output.accept(ModItems.CARTRIDGE.get());
                        output.accept(ModItems.CASING.get());
                    })
                    .build());

    private static ItemStack loadedPistol() {
        ItemStack stack = new ItemStack(ModItems.PISTOL.get());
        PistolItem.setAmmo(stack, PistolItem.MAGAZINE_SIZE);
        return stack;
    }

    private ModCreativeTabs() {}
}
