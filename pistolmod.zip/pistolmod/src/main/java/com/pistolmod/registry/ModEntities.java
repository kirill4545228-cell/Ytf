package com.pistolmod.registry;

import com.pistolmod.PistolMod;
import com.pistolmod.entity.BulletEntity;
import com.pistolmod.entity.CasingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PistolMod.MODID);

    public static final RegistryObject<EntityType<BulletEntity>> BULLET = ENTITIES.register("bullet",
            () -> EntityType.Builder.<BulletEntity>of(BulletEntity::new, MobCategory.MISC)
                    .sized(0.2F, 0.2F)
                    .clientTrackingRange(8)
                    .updateInterval(1)
                    .noSummon()
                    .build(PistolMod.MODID + ":bullet"));

    public static final RegistryObject<EntityType<CasingEntity>> CASING = ENTITIES.register("casing",
            () -> EntityType.Builder.<CasingEntity>of(CasingEntity::new, MobCategory.MISC)
                    .sized(0.15F, 0.15F)
                    .clientTrackingRange(4)
                    .updateInterval(1)
                    .noSummon()
                    .build(PistolMod.MODID + ":casing"));

    private ModEntities() {}
}
