package com.pistolmod.registry;

import com.pistolmod.PistolMod;
import com.pistolmod.item.PistolItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PistolMod.MODID);

    public static final RegistryObject<Item> PISTOL =
            ITEMS.register("pistol", () -> new PistolItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CARTRIDGE =
            ITEMS.register("cartridge", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> CASING =
            ITEMS.register("casing", () -> new Item(new Item.Properties()));

    private ModItems() {}
}
