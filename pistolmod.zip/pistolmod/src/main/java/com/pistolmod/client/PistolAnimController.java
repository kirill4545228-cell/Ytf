package com.pistolmod.client;

import net.minecraft.Util;

/** Клиентское состояние анимации пистолета: что играет сейчас и сколько секунд прошло. */
public final class PistolAnimController {
    /** Снимок для одного кадра рендера. */
    public record Frame(String name, PistolAnimations.Animation anim, float time) {
    }

    private static String current;
    private static long startNanos;
    private static final long IDLE_START = Util.getNanos();

    private PistolAnimController() {}

    public static void play(String name) {
        if (PistolAnimations.get(name) == null) return;
        current = name;
        startNanos = Util.getNanos();
    }

    public static void reset() {
        current = null;
    }

    public static boolean isPlaying(String name) {
        if (current == null || !current.equals(name)) return false;
        PistolAnimations.Animation a = PistolAnimations.get(name);
        return a != null && elapsed() < a.length();
    }

    public static boolean isBusy() {
        return isPlaying("reload") || isPlaying("inspect") || isPlaying("shoot");
    }

    /** Псевдослучайное число, постоянное в пределах одного выстрела (для поворота вспышки). */
    public static int shotSeed() {
        return (int) ((startNanos >> 12) & 0xFFFF);
    }

    /** Выбирает анимацию на этот кадр: играющую, либо зацикленную "hold". Может вернуть null, если анимации не загружены. */
    public static Frame resolve() {
        if (current != null) {
            PistolAnimations.Animation a = PistolAnimations.get(current);
            float t = elapsed();
            if (a != null && t < a.length()) return new Frame(current, a, t);
            current = null;
        }
        PistolAnimations.Animation idle = PistolAnimations.get("hold");
        if (idle == null) return null;
        float t = (Util.getNanos() - IDLE_START) / 1.0E9F;
        if (idle.loop() && idle.length() > 0) t %= idle.length();
        return new Frame("hold", idle, t);
    }

    private static float elapsed() {
        return (Util.getNanos() - startNanos) / 1.0E9F;
    }
}
