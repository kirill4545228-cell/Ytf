package com.pistolmod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.pistolmod.entity.CasingEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;

/** Гильза кувыркается первые ~16 тиков и затем лежит на боку. */
public class CasingRenderer extends EntityRenderer<CasingEntity> {
    private static final float SCALE = 0.35F;
    // центр модели гильзы в пикселях
    private static final float CX = 8.0F, CY = 6.15F, CZ = 8.0F;
    private static final float SPIN_TICKS = 16.0F;

    public CasingRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public ResourceLocation getTextureLocation(CasingEntity entity) {
        return InventoryMenu.BLOCK_ATLAS;
    }

    @Override
    public void render(CasingEntity entity, float entityYaw, float partialTick, PoseStack ps,
                       MultiBufferSource buffers, int light) {
        float t = Math.min(entity.tickCount + partialTick, SPIN_TICKS);
        float spin = t / SPIN_TICKS * 810.0F; // 810 = 2 оборота + 90 градусов, т.е. остановится лёжа
        float yaw = (entity.getId() * 47 % 360);

        ps.pushPose();
        ps.translate(0.0, entity.getBbHeight() / 2.0F, 0.0);
        ps.mulPose(Axis.YP.rotationDegrees(yaw));
        ps.mulPose(Axis.XP.rotationDegrees(spin));
        ps.scale(SCALE, SCALE, SCALE);
        ps.translate(-CX / 16.0F, -CY / 16.0F, -CZ / 16.0F);

        VertexConsumer vc = buffers.getBuffer(Sheets.cutoutBlockSheet());
        Minecraft.getInstance().getItemRenderer().renderModelLists(
                PistolModels.get(PistolModels.CASING), ItemStack.EMPTY, light, OverlayTexture.NO_OVERLAY, ps, vc);
        ps.popPose();
    }
}
