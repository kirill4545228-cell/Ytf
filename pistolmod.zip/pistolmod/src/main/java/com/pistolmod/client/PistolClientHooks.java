package com.pistolmod.client;

import com.pistolmod.item.PistolItem;
import com.pistolmod.network.ModNetwork;
import com.pistolmod.network.ReloadPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Единственная точка входа общего кода в клиентскую часть (вызывается через DistExecutor). */
public final class PistolClientHooks {
    private PistolClientHooks() {}

    public static void onShoot() {
        PistolAnimController.play("shoot");
    }

    public static boolean isReloadAnimating() {
        return PistolAnimController.isPlaying("reload");
    }

    public static void onReloadKey() {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || isReloadAnimating()) return;
        ItemStack stack = PistolItem.findHeld(player);
        if (stack.isEmpty() || !PistolItem.canReload(player, stack, player.level())) return;

        PistolAnimController.play("reload"); // сразу играем анимацию, сервер подтвердит пакетом
        ModNetwork.CHANNEL.sendToServer(new ReloadPacket());
    }

    public static void onInspectKey() {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || PistolItem.findHeld(player).isEmpty()) return;
        if (PistolAnimController.isBusy()) return;
        PistolAnimController.play("inspect");
    }
}
