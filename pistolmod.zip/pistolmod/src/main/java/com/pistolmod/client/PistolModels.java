package com.pistolmod.client;

import com.pistolmod.PistolMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** Дополнительные модели, которые запекаются отдельно от моделей предметов. */
public final class PistolModels {
    public static final ResourceLocation FRAME = rl("item/pistol_frame");
    public static final ResourceLocation SLIDE = rl("item/pistol_slide");
    public static final ResourceLocation MAGAZINE = rl("item/pistol_magazine");
    public static final ResourceLocation TRIGGER = rl("item/pistol_trigger");
    public static final ResourceLocation HAMMER = rl("item/pistol_hammer");
    public static final ResourceLocation MUZZLE_FLASH = rl("item/muzzle_flash");
    public static final ResourceLocation PROJECTILE = rl("item/projectile");
    public static final ResourceLocation CASING = rl("item/casing");

    private PistolModels() {}

    private static ResourceLocation rl(String path) {
        return new ResourceLocation(PistolMod.MODID, path);
    }

    public static List<ResourceLocation> all() {
        return List.of(FRAME, SLIDE, MAGAZINE, TRIGGER, HAMMER, MUZZLE_FLASH, PROJECTILE, CASING);
    }

    public static BakedModel get(ResourceLocation location) {
        return Minecraft.getInstance().getModelManager().getModel(location);
    }
}
