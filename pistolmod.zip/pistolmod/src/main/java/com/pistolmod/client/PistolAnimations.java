package com.pistolmod.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pistolmod.PistolMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Загрузчик анимаций (assets/pistolmod/animations/pistol.json) и сэмплер ключевых кадров.
 * Формат тот же, что в Blockbench: position (пиксели модели), rotation (градусы), scale;
 * интерполяция linear или catmullrom.
 */
public final class PistolAnimations extends SimplePreparableReloadListener<Map<String, PistolAnimations.Animation>> {
    public static final PistolAnimations INSTANCE = new PistolAnimations();
    private static final ResourceLocation FILE = new ResourceLocation(PistolMod.MODID, "animations/pistol.json");

    private static volatile Map<String, Animation> animations = Map.of();

    public static Animation get(String name) {
        return animations.get(name);
    }

    // ------------------------------------------------------------------ данные

    public record Keyframe(float time, float x, float y, float z, boolean smooth) {
        float v(int i) {
            return i == 0 ? x : i == 1 ? y : z;
        }
    }

    /** Поза одной кости в конкретный момент времени. */
    public static final class Pose {
        public final float[] pos = new float[3];
        public final float[] rot = new float[3];
        public final float[] scl = {1, 1, 1};

        public boolean visible() {
            return scl[0] > 0.01F && scl[1] > 0.01F && scl[2] > 0.01F;
        }
    }

    public static final class Animation {
        private final float length;
        private final boolean loop;
        private final Map<String, Map<String, Keyframe[]>> bones;

        Animation(float length, boolean loop, Map<String, Map<String, Keyframe[]>> bones) {
            this.length = length;
            this.loop = loop;
            this.bones = bones;
        }

        public float length() {
            return length;
        }

        public boolean loop() {
            return loop;
        }

        public Pose sample(String bone, float t) {
            Pose pose = new Pose();
            Map<String, Keyframe[]> tracks = bones.get(bone);
            if (tracks != null) {
                sampleTrack(tracks.get("position"), t, pose.pos);
                sampleTrack(tracks.get("rotation"), t, pose.rot);
                sampleTrack(tracks.get("scale"), t, pose.scl);
            }
            return pose;
        }
    }

    // ------------------------------------------------------------------ сэмплер

    private static void sampleTrack(Keyframe[] f, float t, float[] out) {
        if (f == null || f.length == 0) return;
        if (t <= f[0].time()) {
            set(out, f[0]);
            return;
        }
        Keyframe last = f[f.length - 1];
        if (t >= last.time()) {
            set(out, last);
            return;
        }
        int i = 0;
        while (i < f.length - 2 && t >= f[i + 1].time()) i++;
        Keyframe a = f[i];
        Keyframe b = f[i + 1];
        float dt = b.time() - a.time();
        float u = dt > 1.0E-6F ? (t - a.time()) / dt : 1.0F;

        if (a.smooth() || b.smooth()) {
            Keyframe p0 = i > 0 ? f[i - 1] : a;
            Keyframe p3 = i + 2 < f.length ? f[i + 2] : b;
            for (int k = 0; k < 3; k++) {
                out[k] = catmullRom(p0.v(k), a.v(k), b.v(k), p3.v(k), u);
            }
        } else {
            for (int k = 0; k < 3; k++) {
                out[k] = a.v(k) + (b.v(k) - a.v(k)) * u;
            }
        }
    }

    private static void set(float[] out, Keyframe k) {
        out[0] = k.x();
        out[1] = k.y();
        out[2] = k.z();
    }

    private static float catmullRom(float p0, float p1, float p2, float p3, float u) {
        float u2 = u * u;
        float u3 = u2 * u;
        return 0.5F * ((2 * p1) + (-p0 + p2) * u + (2 * p0 - 5 * p1 + 4 * p2 - p3) * u2 + (-p0 + 3 * p1 - 3 * p2 + p3) * u3);
    }

    // ------------------------------------------------------------------ загрузка

    @Override
    protected Map<String, Animation> prepare(ResourceManager manager, ProfilerFiller profiler) {
        Map<String, Animation> result = new HashMap<>();
        try (BufferedReader reader = manager.openAsReader(FILE)) {
            JsonObject root = GsonHelper.parse(reader);
            JsonObject all = GsonHelper.getAsJsonObject(root, "animations");
            for (Map.Entry<String, JsonElement> e : all.entrySet()) {
                JsonObject a = e.getValue().getAsJsonObject();
                Map<String, Map<String, Keyframe[]>> bones = new HashMap<>();
                for (Map.Entry<String, JsonElement> b : GsonHelper.getAsJsonObject(a, "bones").entrySet()) {
                    Map<String, Keyframe[]> tracks = new HashMap<>();
                    for (Map.Entry<String, JsonElement> t : b.getValue().getAsJsonObject().entrySet()) {
                        tracks.put(t.getKey(), parseTrack(t.getValue().getAsJsonArray()));
                    }
                    bones.put(b.getKey(), tracks);
                }
                result.put(e.getKey(), new Animation(
                        GsonHelper.getAsFloat(a, "length"), GsonHelper.getAsBoolean(a, "loop", false), bones));
            }
        } catch (Exception ex) {
            PistolMod.LOGGER.error("Failed to load pistol animations", ex);
        }
        return result;
    }

    private static Keyframe[] parseTrack(JsonArray array) {
        List<Keyframe> list = new ArrayList<>();
        for (JsonElement el : array) {
            JsonObject o = el.getAsJsonObject();
            JsonArray v = GsonHelper.getAsJsonArray(o, "value");
            list.add(new Keyframe(GsonHelper.getAsFloat(o, "time"),
                    v.get(0).getAsFloat(), v.get(1).getAsFloat(), v.get(2).getAsFloat(),
                    GsonHelper.getAsBoolean(o, "smooth", false)));
        }
        list.sort((p, q) -> Float.compare(p.time(), q.time()));
        return list.toArray(new Keyframe[0]);
    }

    @Override
    protected void apply(Map<String, Animation> loaded, ResourceManager manager, ProfilerFiller profiler) {
        animations = loaded;
    }
}
