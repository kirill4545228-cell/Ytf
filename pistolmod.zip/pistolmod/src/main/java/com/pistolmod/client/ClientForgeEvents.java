package com.pistolmod.client;

import com.pistolmod.PistolMod;
import com.pistolmod.item.PistolItem;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** События игровой шины, только на клиенте: клавиши и сброс анимации. */
@Mod.EventBusSubscriber(modid = PistolMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private static int lastSlot = -1;

    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null) {
            PistolAnimController.reset();
            return;
        }

        ItemStack held = PistolItem.findHeld(player);
        int slot = player.getInventory().selected;
        // убрали пистолет или переключили слот - любая анимация обрывается
        if (held.isEmpty() || slot != lastSlot) {
            PistolAnimController.reset();
        }
        lastSlot = slot;

        while (ModKeys.RELOAD.consumeClick()) {
            if (!held.isEmpty() && mc.screen == null) PistolClientHooks.onReloadKey();
        }
        while (ModKeys.INSPECT.consumeClick()) {
            if (!held.isEmpty() && mc.screen == null) PistolClientHooks.onInspectKey();
        }
    }
}
