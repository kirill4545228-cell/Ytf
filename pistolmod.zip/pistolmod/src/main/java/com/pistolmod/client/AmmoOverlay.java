package com.pistolmod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.pistolmod.item.PistolItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Счётчик патронов в правом нижнем углу, пока в руке пистолет. */
public class AmmoOverlay implements IGuiOverlay {
    @Override
    public void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.options.hideGui) return;
        ItemStack stack = PistolItem.findHeld(player);
        if (stack.isEmpty()) return;

        Font font = mc.font;
        int ammo = PistolItem.getAmmo(stack);
        boolean creative = player.getAbilities().instabuild;
        int reserve = PistolItem.countAmmo(player);
        boolean reloading = PistolClientHooks.isReloadAnimating();

        int color = ammo == 0 ? 0xFF5555 : ammo <= 3 ? 0xFFAA00 : 0xFFFFFF;

        // крупное число патронов в магазине
        String big = String.valueOf(ammo);
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(width - 16, height - 46, 0);
        ps.scale(2.0F, 2.0F, 1.0F);
        g.drawString(font, big, -font.width(big), 0, color, true);
        ps.popPose();

        // "/12  +36"
        String small = "/" + PistolItem.MAGAZINE_SIZE + (creative ? "" : "  +" + reserve);
        g.drawString(font, small, width - 16 - font.width(small), height - 28, 0xAAAAAA, true);

        // подсказка
        if (reloading) {
            g.drawCenteredString(font, Component.translatable("hud.pistolmod.reloading"),
                    width / 2, height - 60, 0xFFFFFF);
        } else if (ammo == 0 && (creative || reserve > 0) && (System.currentTimeMillis() / 400) % 2 == 0) {
            g.drawCenteredString(font,
                    Component.translatable("hud.pistolmod.reload", ModKeys.RELOAD.getTranslatedKeyMessage()),
                    width / 2, height - 60, 0xFF5555);
        }
    }
}
