package com.pistolmod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.pistolmod.entity.BulletEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;

/** Рисует пулю моделью projectile.json, повёрнутой по вектору полёта. Модель смотрит носом в -Z. */
public class BulletRenderer extends EntityRenderer<BulletEntity> {
    // центр модели пули в пикселях: x=8, y=8, z=(5.0+11.6)/2
    private static final float CENTER_Z = 8.3F;

    public BulletRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(BulletEntity entity) {
        return InventoryMenu.BLOCK_ATLAS;
    }

    @Override
    public void render(BulletEntity entity, float entityYaw, float partialTick, PoseStack ps,
                       MultiBufferSource buffers, int light) {
        if (entity.tickCount < 2) return; // не рисуем в упор перед камерой стрелка

        float yaw = Mth.lerp(partialTick, entity.yRotO, entity.getYRot());
        float pitch = Mth.lerp(partialTick, entity.xRotO, entity.getXRot());

        ps.pushPose();
        ps.translate(0.0, entity.getBbHeight() / 2.0F, 0.0);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - yaw));
        ps.mulPose(Axis.XP.rotationDegrees(-pitch));
        ps.translate(-0.5F, -0.5F, -CENTER_Z / 16.0F);

        VertexConsumer vc = buffers.getBuffer(Sheets.cutoutBlockSheet());
        // пуля-трассер светится
        ItemRenderer ir = net.minecraft.client.Minecraft.getInstance().getItemRenderer();
        ir.renderModelLists(PistolModels.get(PistolModels.PROJECTILE), ItemStack.EMPTY,
                LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, ps, vc);
        ps.popPose();
    }
}
