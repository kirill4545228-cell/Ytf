package com.pistolmod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Рисует пистолет по частям (рама, затвор, магазин, спусковой крючок, курок) и применяет к каждой
 * части анимацию. Анимация включается только в виде от первого лица; в остальных видах
 * (инвентарь, рука другого игрока, рамка, земля) пистолет статичен.
 *
 * Координаты опорных точек (pivot) - в пикселях модели (1/16 блока), как в Blockbench.
 */
public class PistolItemRenderer extends BlockEntityWithoutLevelRenderer {
    // дуло: центр ствола на переднем срезе
    private static final float MUZZLE_X = 8.0F, MUZZLE_Y = 9.9F, MUZZLE_Z = 1.3F;
    // точка модели вспышки, которая должна совпасть с дулом (основание вспышки)
    private static final float FLASH_BASE_X = 8.0F, FLASH_BASE_Y = 8.0F, FLASH_BASE_Z = 8.5F;
    private static final float FLASH_DURATION = 0.075F;

    public PistolItemRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps,
                             MultiBufferSource buffers, int light, int overlay) {
        ItemRenderer ir = Minecraft.getInstance().getItemRenderer();
        VertexConsumer vc = ItemRenderer.getFoilBufferDirect(buffers, Sheets.cutoutBlockSheet(), true, stack.hasFoil());

        PistolAnimController.Frame frame = ctx.firstPerson() ? PistolAnimController.resolve() : null;

        ps.pushPose();
        // корневая кость: двигает весь пистолет целиком (отдача, наклон, осмотр)
        PistolAnimations.Pose gun = pose(frame, "gun");
        transform(ps, gun, 8.0F, 5.0F, 8.0F);

        draw(ir, PistolModels.FRAME, stack, ps, vc, light, overlay);
        bone(ir, frame, "slide", PistolModels.SLIDE, 8.0F, 10.0F, 8.0F, stack, ps, vc, light, overlay);
        bone(ir, frame, "magazine", PistolModels.MAGAZINE, 8.0F, 4.0F, 12.5F, stack, ps, vc, light, overlay);
        bone(ir, frame, "trigger", PistolModels.TRIGGER, 8.0F, 7.9F, 8.8F, stack, ps, vc, light, overlay);
        bone(ir, frame, "hammer", PistolModels.HAMMER, 8.0F, 9.3F, 14.3F, stack, ps, vc, light, overlay);

        if (frame != null && "shoot".equals(frame.name()) && frame.time() < FLASH_DURATION) {
            renderMuzzleFlash(ir, frame, ps, vc);
        }
        ps.popPose();
    }

    private void renderMuzzleFlash(ItemRenderer ir, PistolAnimController.Frame frame, PoseStack ps, VertexConsumer vc) {
        int seed = PistolAnimController.shotSeed();
        float fade = 1.0F - frame.time() / (FLASH_DURATION * 2.0F);
        float scale = (0.8F + (seed % 5) * 0.08F) * fade;

        ps.pushPose();
        ps.translate(MUZZLE_X / 16.0F, MUZZLE_Y / 16.0F, MUZZLE_Z / 16.0F);
        ps.mulPose(Axis.ZP.rotationDegrees((seed % 8) * 45.0F)); // каждый выстрел вспышка повёрнута по-разному
        ps.scale(scale, scale, scale);
        ps.translate(-FLASH_BASE_X / 16.0F, -FLASH_BASE_Y / 16.0F, -FLASH_BASE_Z / 16.0F);
        // вспышка светится: максимальная яркость независимо от освещения
        ir.renderModelLists(PistolModels.get(PistolModels.MUZZLE_FLASH), ItemStack.EMPTY,
                LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, ps, vc);
        ps.popPose();
    }

    // ------------------------------------------------------------------ помощники

    private static PistolAnimations.Pose pose(PistolAnimController.Frame frame, String bone) {
        return frame == null ? new PistolAnimations.Pose() : frame.anim().sample(bone, frame.time());
    }

    private void bone(ItemRenderer ir, PistolAnimController.Frame frame, String name, ResourceLocation model,
                      float px, float py, float pz, ItemStack stack, PoseStack ps, VertexConsumer vc,
                      int light, int overlay) {
        PistolAnimations.Pose p = pose(frame, name);
        if (!p.visible()) return; // например, магазин на время, пока он «выпал» при перезарядке
        ps.pushPose();
        transform(ps, p, px, py, pz);
        draw(ir, model, stack, ps, vc, light, overlay);
        ps.popPose();
    }

    /**
     * Порядок как в Blockbench: перенос в опорную точку + смещение, затем поворот ZYX, масштаб,
     * и возврат из опорной точки. Единицы - пиксели модели (делим на 16).
     * Положительный X-поворот поднимает дуло вверх, положительное Z-смещение - к игроку.
     */
    private static void transform(PoseStack ps, PistolAnimations.Pose p, float px, float py, float pz) {
        ps.translate((px + p.pos[0]) / 16.0F, (py + p.pos[1]) / 16.0F, (pz + p.pos[2]) / 16.0F);
        if (p.rot[2] != 0.0F) ps.mulPose(Axis.ZP.rotationDegrees(p.rot[2]));
        if (p.rot[1] != 0.0F) ps.mulPose(Axis.YP.rotationDegrees(p.rot[1]));
        if (p.rot[0] != 0.0F) ps.mulPose(Axis.XP.rotationDegrees(p.rot[0]));
        if (p.scl[0] != 1.0F || p.scl[1] != 1.0F || p.scl[2] != 1.0F) ps.scale(p.scl[0], p.scl[1], p.scl[2]);
        ps.translate(-px / 16.0F, -py / 16.0F, -pz / 16.0F);
    }

    private static void draw(ItemRenderer ir, ResourceLocation model, ItemStack stack, PoseStack ps,
                             VertexConsumer vc, int light, int overlay) {
        BakedModel baked = PistolModels.get(model);
        ir.renderModelLists(baked, stack, light, overlay, ps, vc);
    }
}
