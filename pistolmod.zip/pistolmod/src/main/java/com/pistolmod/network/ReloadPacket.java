package com.pistolmod.network;

import com.pistolmod.item.PistolItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Клиент -> сервер: игрок нажал клавишу перезарядки. */
public class ReloadPacket {
    public static void encode(ReloadPacket msg, FriendlyByteBuf buf) {
    }

    public static ReloadPacket decode(FriendlyByteBuf buf) {
        return new ReloadPacket();
    }

    public static void handle(ReloadPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) {
            ItemStack stack = PistolItem.findHeld(player);
            if (!stack.isEmpty()) {
                PistolItem.startReload(player, stack);
            }
        }
        ctx.get().setPacketHandled(true);
    }
}
