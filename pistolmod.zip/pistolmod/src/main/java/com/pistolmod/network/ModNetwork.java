package com.pistolmod.network;

import com.pistolmod.PistolMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(PistolMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.messageBuilder(ReloadPacket.class, 0, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ReloadPacket::encode)
                .decoder(ReloadPacket::decode)
                .consumerMainThread(ReloadPacket::handle)
                .add();
    }

    private ModNetwork() {}
}
